#include "stdafx.h"

void printError(char *Format, ...)
{
	char Dest; // [esp+0h] [ebp-400h]
	va_list Args; // [esp+40Ch] [ebp+Ch]

	va_start(Args, Format);
	vsprintf(&Dest, Format, Args);
	fprintf(&iob[2], &Dest);
	OutputDebugStringA(&Dest);
}

void printMessage(char *Format, ...)
{
	char Dest; // [esp+0h] [ebp-400h]
	va_list va; // [esp+40Ch] [ebp+Ch]

	va_start(va, Format);
	if ( verboseFlag )
	{
		vsprintf(&Dest, Format, va);
		printf(&Dest);
		OutputDebugStringA(&Dest);
	}
}

int __cdecl main(int argc, const char **argv, const char **envp)
{
	HMODULE v3; // eax
	BOOL i; // eax
	MSG msg; // [esp+8h] [ebp-1Ch]

	v3 = GetModuleHandleA(0);
	if ( createAWindow(v3) && parseCommandLine(argc, argv) && sub_4015C7() )
	{
		for ( i = GetMessageA(&msg, 0, 0, 0); i > 0; i = GetMessageA(&msg, 0, 0, 0) )
		{
			TranslateMessage(&msg);
			DispatchMessageA(&msg);
		}
	}
	closeWindow();
	return 0;
}

signed int __cdecl createAWindow(HINSTANCE hInstance)
{
	struct WSAData WSAData; // [esp+Ch] [ebp-1B8h]
	WNDCLASSA WndClass; // [esp+19Ch] [ebp-28h]

	InitializeCriticalSection(&g_csSync);
	theDestIP = -1;
	s = -1;
	hWnd = 0;
	quitSignal = 0;
	verboseFlag = 0;
	UDPFlag = 0;
	tcporudp = 1;
	*(DWORD *)&LFlagPort= 0;??
	*(DWORD *)&sFlagSourcePort = 0;
	*(DWORD *)&rFlagPort = 0;
	iFlagIP = 0;
	maxConnections = 32;
	SetConsoleCtrlHandler(HandlerRoutine, 1);
	printError(Format);
	WndClass.hInstance = hInstance;
	WndClass.style = 0;
	WndClass.lpfnWndProc = (WNDPROC)&createHandler;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hIcon = 0;
	WndClass.hCursor = 0;
	WndClass.hbrBackground = 0;
	WndClass.lpszMenuName = 0;
	WndClass.lpszClassName = WindowName;
	RegisterClassA(&WndClass);
	hWnd = CreateWindowExA(
		0,
		WindowName,
		WindowName,
		0xCF0000u,
		2147483648,
		2147483648,
		2147483648,
		2147483648,
		0,
		0,
		hInstance,
		0);
	if ( !WSAStartup(1u, &WSAData) )
		return 1;
	printError("Unable to start network communications");
	return 0;
}

int closeWindow()
{
	if ( hWnd )
	{
		DestroyWindow(hWnd);
		hWnd = 0;
	}
	if ( s != -1 )
	{
		shutdown(s, 2);
		closesocket(s);
		s = -1;
	}
	closeAllConnections();
	DeleteCriticalSection(&g_csSync);
	return WSACleanup();
}

signed int __cdecl parseCommandLine(signed int argc, char **argv)
{
	char *v2; // eax
	char v3; // bl
	int v4; // eax
	int v6; // [esp+Ch] [ebp-Ch]
	char *i; // [esp+10h] [ebp-8h]
	char v8; // [esp+17h] [ebp-1h]

	v8 = 0;
	if ( argc < 4 )
	{
LABEL_PRINTHELP:
		printUsage();
		return 0;
	}
	if ( argc <= 1 )
		goto LABEL_theDestIP;
	do
	{
		++argv;
		v2 = *argv;
		for ( i = *argv; ; v2 = i )
		{
			v3 = *v2;
			if ( !*v2 )
				break;
			if ( v8 )
			{
				v3 = v8;
				v8 = 0;
			}
			else
			{
				++i;
				if ( v3 == 45 ) // -
					v3 = *i++;
			}
			if ( v3 > 86 ) // V
			{
				if ( v3 <= 114 ) //r
				{
					if ( v3 != 114 ) // r
					{
						if ( v3 != 99 ) // c
						{
							if ( v3 == 104 ) // h
								goto LABEL_PRINTHELP;
							if ( v3 == 105 ) // i
								goto LABEL_IFLAG_Listening_Ip_Provided;
							if ( v3 != 108 ) // l
								goto LABEL_LFlag_Listening_Port_Provided;
LABEL_28:
							if ( !checkIfNumber(&i, &v6) )
								goto LABEL_SaveValue;
							if ( v6 <= 0xFFFF )
								*(DWORD *)&LFlagPort= v6;
							else
								printError("Listening port number out of range");
							continue;
						}
						goto LABEL_CFlag_MaxConnectionsProvided;
					}
LABEL_38:
					if ( !checkIfNumber(&i, &v6) )
						goto LABEL_SaveValue;
					if ( v6 <= 0xFFFF )
						*(DWORD *)&rFlagPort = v6;
					else
						printError("Remote port number out of range");
					continue;
				}
				if ( v3 != 115 ) //s
				{
					if ( v3 != 117 ) // u
					{
						if ( v3 != 118 ) // v
							goto LABEL_LFlag_Listening_Port_Provided;
LABEL_VFlag_Enabled:
						verboseFlag = 1;
						continue;
					}
					goto LABEL_UFlag_Enabled;
				}
			}
			else
			{
				if ( v3 == 86 ) // V
					goto LABEL_VFlag_Enabled;
				if ( v3 <= 76 ) // L
				{
					if ( v3 == 76 ) //L
						goto LABEL_28;
					if ( v3 == 63 ) //?
						goto LABEL_PRINTHELP;
					if ( v3 != 67 ) // C
					{
						if ( v3 == 72 ) // H
							goto LABEL_PRINTHELP;
						if ( v3 != 73 ) // I
						{
LABEL_LFlag_Listening_Port_Provided:
							--i;
							theDestIP = getIPfromHost(&i);
							continue;
						}
LABEL_IFLAG_Listening_Ip_Provided:
						v4 = getIPfromHost(&i);
						if ( v4 != -1 )
						{
							iFlagIP = v4;
							continue;
						}
LABEL_SaveValue:
						v8 = v3;
						continue;
					}
LABEL_CFlag_MaxConnectionsProvided:
					if ( !checkIfNumber(&i, &v6) )
						goto LABEL_SaveValue;
					if ( v6 > 512 )
					{
						printError("Too many connections! Set to %d",512);
						v6 = 512;
					}
					maxConnections = v6;
					continue;
				}
				if ( v3 == 82 )
					goto LABEL_38;
				if ( v3 != 83 )
				{
					if ( v3 != 85 )
						goto LABEL_LFlag_Listening_Port_Provided;
LABEL_UFlag_Enabled:
					UDPFlag = 1;
					tcporudp = 2;
					continue;
				}
			}
			if ( !checkIfNumber(&i, &v6) )
				goto LABEL_SaveValue;
			if ( v6 <= 0xFFFF )
				*(DWORD *)&sFlagSourcePort = v6;
			else
				printError("Source bind port number out of range");
		}
		--argc;
	}
	while ( argc > 1 );
LABEL_theDestIP:
	if ( theDestIP == -1 )
	{
		printError("No IP address provided - using %s", "127.0.0.1");
		i = "127.0.0.1";
		theDestIP = getIPfromHost(&i);
	}
	return 1;
}

signed int __cdecl checkIfNumber(char **a1, int *a2)
{
	int v2; // ecx
	signed int result; // eax
	char *v4; // edx
	char v5; // bl

	v2 = 0;
	result = 0;
	v4 = *a1;
	do
	{
		v5 = *v4++;
		if ( v5 < 48 ) // 0
			break;
		if ( v5 > 57 ) // 9
			break;
		v2 = v5 + 10 * v2 - 48; //0
		result = 1;
	}
	while ( v5 <= 57 ); // 0
	*a1 = v4 - 1;
	*a2 = v2;
	return result;
}

int __cdecl getIPfromHost(char **a1)
{
	unsigned int v1; // ecx
	char v2; // al
	char *v3; // esi
	int result; // eax
	char cp[256]; // [esp+8h] [ebp-100h]

	v1 = 0;
	v2 = **a1;
	v3 = *a1 + 1;
	if ( v2 != 34 ) // "
		goto LABEL_3;
	while ( 1 )
	{
		v2 = *v3++;
LABEL_3:
		if ( !v2 )
			break;
		if ( v2 == ',' || v2 == ':' || v2 == '"' || v2 == ' ' || v1 >= 0xFF )  // , : " SPACE BLANK
			break;
		cp[v1++] = v2;
	}
	cp[v1] = 0;
	result = resolveHostName(cp, 0);
	*a1 = v3 - 1;
	return result;
}

unsigned int __cdecl resolveHostName(char *cp, int a2)
{
	unsigned int v2; // edi
	struct hostent *v3; // eax
	int v4; // eax
	CHAR v6; // [esp+8h] [ebp-20h]

	v2 = -1;
	if ( cp && *cp )
	{
		v2 = inet_addr(cp);
		if ( v2 == -1 )
		{
			if ( a2 )
				*(DWORD *)a2 = 0;
			printMessage('Looking up hostname "%s"', cp);
			v3 = gethostbyname(cp);
			if ( v3 )
			{
				v2 = **(DWORD **)v3->h_addr_list;
				v4 = sub_401A37(**(DWORD **)v3->h_addr_list, &v6);
				printMessage('"%s" resolved to "%s"', cp, v4);
			}
			else
			{
				printError('"Unable to resolve hostname "%s"', cp);
			}
		}
		else if ( a2 )
		{
			*(DWORD *)a2 = 1;
		}
	}
	return v2;
}

signed int __usercall sub_4015C7@<eax>(int a1@<ebp>)
{
	int v1; // ecx
	DWORD *i; // eax
	SOCKET v3; // eax
	int v4; // eax
	int v5; // eax
	int v7; // ST1C_4
	int v8; // eax
	SOCKET *v9; // edi
	SOCKET v10; // eax
	SOCKET v11; // esi
	SOCKET v12; // eax
	SOCKET v13; // esi
	int v14; // ST10_4
	int v15; // eax
	int v16; // [esp-4h] [ebp-28h]
	char optval[4]; // [esp+0h] [ebp-24h]
	CHAR v18; // [esp+4h] [ebp-20h]
	int v19; // [esp+1Ch] [ebp-8h]
	int OutDestPort; // [esp+20h] [ebp-4h]

	v1 = maxConnections;
	for ( i = &unk_404C90; v1; --v1 )
	{
		i[1] = -1;
		*i = -1;
		i += 6;
	}
	socketInHost.sa_family = 2;
	*(_WORD *)socketInHost.sa_data = htons(LFlagPort);
	*(DWORD *)&socketInHost.sa_data[2] = iFlagIP;
	to.sa_family = 2;
	*(_WORD *)to.sa_data = htons(rFlagPort);
	*(DWORD *)&to.sa_data[2] = theDestIP;
	socketOut.sa_family = 2;
	*(_WORD *)socketOut.sa_data = htons(sFlagSourcePort);
	*(DWORD *)&socketOut.sa_data[2] = iFlagIP;
	if ( UDPFlag )
	{
		*(DWORD *)optval = 1;
		v9 = (SOCKET *)checkIfWeExceedMaxConnections();
		if ( !v9 )
		{
			printError("Unable to create new pipe. Maximum number of connections is in use");
			return 0;
		}
		v10 = socket(2, tcporudp, 0);
		v11 = v10;
		*v9 = v10;
		if ( v10 == -1 )
		{
			printError("Unable to create UDP input socket");
LABEL_CloseConnections:
			closeInOutConnections(v9);
			return 0;
		}
		if ( bind(v10, &socketInHost, 16) == -1 )
		{
			printError("Unable to bind to UDP port %d", *(DWORD *)&LFlagPort);
		}
		else
		{
			setsockopt(v11, 0xFFFF, 4, optval, 4);
			WSAAsyncSelect(v11, hWnd, 0xBD1u, 1);
			v12 = socket(2, tcporudp, 0);
			v13 = v12;
			v9[1] = v12;
			if ( v12 == -1 )
			{
				printError("Unable to create UDP output socket");
				goto LABEL_CloseConnections;
			}
			if ( bind(v12, &socketOut, 16) != -1 )
			{
				WSAAsyncSelect(v13, hWnd, 0xBD1u, 1);
				v14 = *(DWORD *)&LFlagPort;
				v15 = sub_401A37(iFlagIP, &v18);
				printMessage("Listening for UDP data on %s port %d", v15, v14);
				return 1;
			}
			printError("Unable to bind to UDP port %d", *(DWORD *)&sFlagSourcePort);
		}
		closeInOutConnections(v9);
		return 0;
	}
	OutDestPort = a1;
	v19 = 1;
	v3 = socket(2, tcporudp, 0);
	s = v3;
	if ( v3 == -1 )
	{
		v4 = WSAGetLastError();
		printError("Unable to create TCP listen socket. %s%d", aWinsockErrorCo, v4);
		return 0;
	}
	WSAAsyncSelect(v3, hWnd, 0xBD0u, 8);
	setsockopt(s, 0xFFFF, 4, (const char *)&v19, 4);
	if ( bind(s, &socketInHost, 16) == -1 )
	{
		v5 = WSAGetLastError();
		if ( v5 == 10048 )
			printError("TCP port %d is already in use by another program", *(DWORD *)&LFlagPort);
		else
			printError("Unable to bind to TCP port %d. %s%d", *(DWORD *)&LFlagPort, aWinsockErrorCo, v5);
		return 0;
	}
	listen(s, 1);
	v7 = *(DWORD *)&LFlagPort;
	v8 = sub_401A37(iFlagIP, (LPSTR)&v16);
	printMessage("Listening for TCP connections on %s port %d", v8, v7);
	return 1;
}

int closeAllConnections()
{
	unsigned int v0; // esi
	char *v1; // edi
	int result; // eax

	v0 = 0;
	v1 = (char *)&unk_404C90;
	if ( maxConnections )
	{
		do
		{
			result = closeInOutConnections(v1);
			v1 += 24;
			++v0;
		}
		while ( v0 < maxConnections );
	}
	return result;
}

void __cdecl closeInOutConnections(SOCKET *a1)
{
	EnterCriticalSection(&g_csSync);
	if ( a1 )
	{
		if ( a1[1] != -1 )
		{
			printMessage("Closing outbound connection");
			shutdown(a1[1], 2);
			closesocket(a1[1]);
			if ( IsWindow(hWnd) )
				WSAAsyncSelect(a1[1], hWnd, 0, 0);
			a1[1] = -1;
		}
		if ( *a1 != -1 )
		{
			printMessage("Closing inbound connection");
			shutdown(*a1, 2);
			closesocket(*a1);
			if ( IsWindow(hWnd) )
				WSAAsyncSelect(*a1, hWnd, 0, 0);
			*a1 = -1;
		}
	}
	LeaveCriticalSection(&g_csSync);
}

DWORD *checkIfWeExceedMaxConnections()
{
	DWORD *v0; // esi
	DWORD *v1; // ebp
	int v2; // ecx

	v0 = &unk_404C90;
	v1 = 0;
	EnterCriticalSection(&g_csSync);
	v2 = 0;
	if ( maxConnections )
	{
		while ( *v0 != -1 || v0[1] != -1 )
		{
			v0 += 6;
			if ( ++v2 >= (unsigned int)maxConnections )
				goto LABEL_7;
		}
		v1 = v0;
		v0[2] = 0;
		v0[3] = 0;
		v0[4] = 0;
		v0[5] = 0;
	}
LABEL_7:
	LeaveCriticalSection(&g_csSync);
	return v1;
}

DWORD *__cdecl addConnectionToPool(SOCKET sock, int a2)
{
	DWORD *v2; // esi
	int v3; // ecx
	signed int v4; // edx
	DWORD *v6; // [esp+Ch] [ebp-8h]
	int v7; // [esp+10h] [ebp-4h]
	signed int v8; // [esp+1Ch] [ebp+8h]

	v6 = 0;
	v2 = &unk_404C90;
	EnterCriticalSection(&g_csSync);
	v7 = 0;
	if ( maxConnections )
	{
		v3 = a1;
		while ( 1 )
		{
			v8 = 0;
			v4 = 0;
			if ( v3 == *v2 || !v3 )
				v4 = 1;
			if ( a2 == v2[1] || !a2 )
				v8 = 1;
			if ( v4 && v8 )
				break;
			v2 += 6;
			if ( ++v7 >= (unsigned int)maxConnections )
				goto LABEL_14;
		}
		v6 = v2;
	}
LABEL_14:
	LeaveCriticalSection(&g_csSync);
	return v6;
}

LPSTR __cdecl sub_401A37(int a1, LPSTR a2)
{
	unsigned int v2; // eax

	v2 = (unsigned int)a1 >> 16;
	wsprintfA(a2, aDDDD, (unsigned __int8)a1, BYTE1(a1), BYTE2(a1), BYTE1(v2));
	return a2;
}

LRESULT __stdcall createHandler(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	int v5; // edi
	DWORD *v6; // esi
	int v7; // ST20_4
	int v8; // ST20_4
	char *v9; // eax
	int v10; // ST20_4
	int v11; // ST20_4
	int v12; // ST20_4
	unsigned int v13; // edi
	SOCKET *v14; // esi
	SOCKET *v15; // esi
	char *v16; // eax
	char *v17; // eax
	char *v18; // eax
	char *v19; // eax
	int OutDestPort; // ST20_4
	int OutHostPort; // ST18_4
	int InDestPort; // ST10_4
	u_short InHostPort; // ax
	SOCKET v24; // esi
	int v25; // ST20_4
	int v26; // ST20_4
	char *v27; // eax
	SOCKET *v28; // eax
	SOCKET v29; // esi
	int DestPort; // ST20_4
	char *DestIP; // eax
	int v32; // eax
	int v33; // ST20_4
	char *v34; // eax
	int v35; // ST20_4
	int v36; // ST1C_4
	char *v37; // eax
	int v38; // ST20_4
	int v39; // esi
	SOCKET *v40; // edi
	int v41; // ST20_4
	int v42; // ST20_4
	int v43; // ST20_4
	int v44; // ST20_4
	char buf; // [esp+Ch] [ebp-8D0h]
	CHAR OutHostIP; // [esp+80Ch] [ebp-D0h]
	CHAR InHostIpAddress; // [esp+82Ch] [ebp-B0h]
	CHAR InDestIP; // [esp+84Ch] [ebp-90h]
	CHAR OutDestIp; // [esp+86Ch] [ebp-70h]
	struct sockaddr socketDest; // [esp+88Ch] [ebp-50h]
	struct sockaddr socketOutHost; // [esp+89Ch] [ebp-40h]
	struct sockaddr socketInDest; // [esp+8ACh] [ebp-30h]
	struct sockaddr socketInHost; // [esp+8BCh] [ebp-20h]
	struct sockaddr from; // [esp+8CCh] [ebp-10h]
	SOCKET *Msga; // [esp+8E8h] [ebp+Ch]

	switch ( Msg )
	{
	case 2u:
		::hWnd = 0;
		PostQuitMessage(0);
		return 0;
	case 0xBD0u:
		v13 = (unsigned int)lParam >> 16;
		switch ( (unsigned __int16)lParam )
		{
		case 1u:
			if ( v13 )
			{
				printError("Error %d occurred when reading from connection" (unsigned int)lParam >> 16);
				return 0;
			}
			lParam = 16;
			v39 = recvfrom(wParam, &buf, 2048, 0, &from, &lParam);
			v40 = addConnectionToPool(wParam, 0);
			if ( v40 )
			{
				if ( v39 == -1 )
				{
					v41 = WSAGetLastError();
					printError("Error %d occurred when reading from inbound connection", v41);
				}
				else
				{
					printMessage("%d bytes received from inbound connection"); // not sure what %d is
					if ( send(v40[1], &buf, v39, 0) != -1 )
						return 0;
					v42 = WSAGetLastError();
					printError("Error %d occurred when sending to outbound connection", v42);
				}
			}
			else
			{
				v40 = addConnectionToPool(0, wParam);
				if ( !v40 )
					return 0;
				if ( v39 == -1 )
				{
					v43 = WSAGetLastError();
					printError("Error %d occurred when reading from outbound connection", v43);
				}
				else
				{
					printMessage("%d bytes received from outbound connection"); //not sure what %d is
					if ( send(*v40, &buf, v39, 0) != -1 )
						return 0;
					v44 = WSAGetLastError();
					printError("Error %d occurred when sending to inbound connection", v44);
				}
			}
			closeInOutConnections(v40);
			return 0;
		case 8u:
			if ( wParam == s )
			{
				if ( v13 )
				{
					v38 = WSAGetLastError();
					printError("Error %d occurred when accepting remote connection", v38);
				}
				else
				{
					lParam = 16;
					v24 = accept(wParam, &from, &lParam);
					if ( v24 == -1 )
					{
						v25 = WSAGetLastError();
						printError("Error %d occurred when accepting inbound connection", v25);
					}
					else
					{
						wParam = 1;
						v26 = ntohs(*(u_short *)from.sa_data);
						v27 = inet_ntoa(*(struct in_addr *)&from.sa_data[2]);
						printMessage("Connection accepted from %s port %d", v27, v26);
						v28 = checkIfWeExceedMaxConnections();
						Msga = v28;
						if ( v28 )
						{
							*v28 = v24;
							v29 = socket(2, tcporudp, 0);
							if ( v29 == -1 )
							{
								printError("Unable to create output socket");
								closeInOutConnections(Msga);
							}
							else
							{
								Msga[1] = v29;
								setsockopt(v29, 0xFFFF, 4, (const char *)&wParam, 4);
								if ( bind(v29, &socketOut, 16) == -1 )
								{
									printError("Unable to bind to port %d", *(DWORD *)&sFlagSourcePort);
									closeInOutConnections(Msga);
								}
								else
								{
									WSAAsyncSelect(v29, ::hWnd, 0xBD0u, 48);
									DestPort = ntohs(*(u_short *)from.sa_data);
									DestIP = inet_ntoa(*(struct in_addr *)&from.sa_data[2]);
									printMessage("Attempting to connect to %s port %d", DestIP, DestPort);
									if ( connect(v29, &to, 16) == -1 )
									{
										v32 = WSAGetLastError();
										if ( v32 != 10035 )
										{
											if ( v32 == 10048 )
											{
												v33 = *(DWORD *)&rFlagPort;
												v34 = inet_ntoa(*(struct in_addr *)&from.sa_data[2]);
												printError("%s %s port %d. Address is already in use", "Unable to connect to remote address", v34, v33);
											}
											else
											{
												v35 = v32;
												v36 = *(DWORD *)&rFlagPort;
												v37 = inet_ntoa(*(struct in_addr *)&from.sa_data[2]);
												printError("%s %s port %d. Error %d", "Unable to connect to remote address", v37, v36, v35);
											}
											closeInOutConnections(Msga);
										}
									}
								}
							}
						}
						else
						{
							printError("Unable to create new pipe. Maximum number of connections is in use");
						}
					}
				}
			}
			return 0;
		case 0x10u:
			v15 = addConnectionToPool(0, wParam);
			if ( v15 )
			{
				if ( v13 )
				{
					if ( v13 == 10048 )
						printError("%s. Address is already in use", "Unable to connect to remote address");
					else
						printError("%s. Error %d", "Unable to connect to remote address", v13);
					closeInOutConnections(v15);
				}
				else
				{
					lParam = 16;
					getpeername(*v15, &socketInHost, &lParam);
					v16 = inet_ntoa(*(struct in_addr *)&socketInHost.sa_data[2]);
					lstrcpyA(&InHostIpAddress, v16);
					lParam = 16;
					getsockname(*v15, &socketInDest, &lParam);
					v17 = inet_ntoa(*(struct in_addr *)&socketInDest.sa_data[2]);
					lstrcpyA(&InDestIP, v17);
					lParam = 16;
					getsockname(v15[1], &socketOutHost, &lParam);
					v18 = inet_ntoa(*(struct in_addr *)&socketOutHost.sa_data[2]);
					lstrcpyA(&OutHostIP, v18);
					lParam = 16;
					getpeername(v15[1], &socketDest, &lParam);
					v19 = inet_ntoa(*(struct in_addr *)&socketDest.sa_data[2]);
					lstrcpyA(&OutDestIp, v19);
					OutDestPort = ntohs(*(u_short *)socketDest.sa_data);
					OutHostPort = ntohs(*(u_short *)socketOutHost.sa_data);
					InDestPort = ntohs(*(u_short *)socketInDest.sa_data);
					InHostPort = ntohs(*(u_short *)socketInHost.sa_data);
					//Pipe connected:
					//In:         127.0.0.1:32192 --> 127.0.0.1:53
					//Out:    192.168.0.157:53    --> 8.8.8.8:80
					printError("Pipe connected:\nIn: %16s:%-5d --> %s:%d\n Out:%16s:%-5d --> %s:%d", &InHostIpAddress, InHostPort, &InDestIP, InDestPort, &OutHostIP, OutHostPort, &OutDestIp, OutDestPort);
					WSAAsyncSelect(*v15, ::hWnd, 0xBD0u, 33);
					WSAAsyncSelect(v15[1], ::hWnd, 0xBD0u, 33);
				}
			}
			return 0;
		case 0x20u:
			v14 = addConnectionToPool(wParam, 0);
			if ( v14 )
			{
				printMessage("Inbound connection lost");
			}
			else
			{
				v14 = addConnectionToPool(0, wParam);
				if ( !v14 )
					return 0;
				printMessage("Outbound connection lost");
			}
			closeInOutConnections(v14);
			return 0;
		}
		break;
	case 0xBD1u:
		if ( (unsigned __int16)lParam == 1 )
		{
			if ( (unsigned int)lParam >> 16 )
			{
				printError("Error %d occurred when reading from UDP connection", (unsigned int)lParam >> 16);
			}
			else
			{
				lParam = 16;
				v5 = recvfrom(wParam, &buf, 2048, 0, &from, &lParam);
				v6 = addConnectionToPool(wParam, 0);
				if ( v6 )
				{
					if ( v5 == -1 )
					{
						v7 = WSAGetLastError();
						printError("Error %d occurred when reading from inbound UDP connection", v7);
					}
					else
					{
						printMessage("%d bytes received from inbound UDP connection"); //what bytes
						if ( *(DWORD *)&from.sa_data[2] != v6[3] || *(_WORD *)from.sa_data != *((_WORD *)v6 + 5) )
						{
							*(struct sockaddr *)(v6 + 2) = from;
							v8 = ntohs(*((_WORD *)v6 + 5));
							v9 = inet_ntoa((struct in_addr)v6[3]);
							printMessage("Setting last UDP source address to %s port %d", v9, v8);
						}
						if ( sendto(v6[1], &buf, v5, 0, &to, 16) != -1 )
							return 0;
						v10 = WSAGetLastError();
						printError("Error %d occurred when sending to outbound UDP connection", v10);
					}
					goto LABEL_22;
				}
				v6 = addConnectionToPool(0, wParam);
				if ( v6 )
				{
					if ( v5 == -1 )
					{
						v11 = WSAGetLastError();
						printError("Error %d occurred when reading from outbound UDP connection", v11);
LABEL_22:
						closeInOutConnections(v6);
						return 0;
					}
					printMessage("%d bytes received from outbound UDP connection", v5);
					if ( v6[3] && *((_WORD *)v6 + 5) )
					{
						if ( sendto(*v6, &buf, v5, 0, (const struct sockaddr *)(v6 + 2), 16) == -1 )
						{
							v12 = WSAGetLastError();
							printError("Error %d occurred when sending to inbound UDP connection", v12);
							goto LABEL_22;
						}
					}
					else
					{
						printError("Data received from outbound connection but I don't know where to send it!");
					}
				}
			}
		}
		break;
	default:
		return DefWindowProcA(hWnd, Msg, wParam, lParam);
	}
	return 0;
}

BOOL __stdcall HandlerRoutine(DWORD CtrlType)
{
	BOOL result; // eax

	if ( !quitSignal )
	{
		printError("Quit signal detected. Shutting down...");
		PostMessageA(hWnd, 0x10u, 0, 0);
	}
	result = 1;
	quitSignal = 1;
	return result;
}

void printUsage()
{
	printError("%s [-hvu?] [-lrs <port>] [-i IP] IP", WindowName);
	printError("-?/-h - shows this help text");
	printError("-c    - maximum allowed simultaneous TCP connections. Default is %d", 32);
	printError("-i    - listening interface IP address");
	printError("-l    - listening port number");
	printError("-r    - remote port number");
	printError("-s    - outbound source port number");
	printError("-u    - UDP mode");
	printError("-v    - verbose mode");
	printError("Example:");
	printError("fpipe -l 53 -s 53 -r 80 192.168.1.101");
	printError("This would set the program to listen for connections on port 53 and");
	printError("when a local connection is detected a further connection will be");
	printError("made to port 80 of the remote machine at 192.168.1.101 with the");
	printError("source port for that outbound connection being set to 53 also.");
	printError("Data sent to and from the connected machines will be passed through.");
}

// void __noreturn start()
// {
// 	int v0; // eax
// 	char **argv; // [esp+10h] [ebp-2Ch]
// 	int v2; // [esp+14h] [ebp-28h]
// 	int v3; // [esp+18h] [ebp-24h]
// 	char **envp; // [esp+1Ch] [ebp-20h]
// 	int argc; // [esp+20h] [ebp-1Ch]
// 	CPPEH_RECORD ms_exc; // [esp+24h] [ebp-18h]
// 
// 	ms_exc.registration.TryLevel = 0;
// 	_set_app_tcporudp(1);
// 	dword_407CCC = -1;
// 	dword_407CD0 = -1;
// 	*(DWORD *)_p__fmode() = dword_407CC8;
// 	*(DWORD *)_p__commode() = dword_407CC4;
// 	dword_407CD4 = adjust_fdiv;
// 	nullsub_1();
// 	if ( !dword_404C38 )
// 		_setusermatherr(sub_402308);
// 	_setdefaultprecision();
// 	initterm(&unk_404008, &unk_40400C);
// 	v2 = dword_407CC0;
// 	_getmainargs(&argc, &argv, &envp, dword_407CBC, &v2);
// 	initterm(&unk_404000, &unk_404004);
// 	*(DWORD *)_p___initenv() = envp;
// 	v0 = main(argc, (const char **)argv, (const char **)envp);
// 	v3 = v0;
// 	exit(v0);
// }
// 
// int XcptFilter()
// {
// 	return _XcptFilter();
// }

/*
int __cdecl initterm(int a1, int a2)
{
	return _initterm(a1, a2);
}

unsigned int _setdefaultprecision()
{
	return controlfp(0x10000u, 0x30000u);
}

int sub_402308()
{
	return 0;
}

unsigned int __cdecl controlfp(unsigned int NewValue, unsigned int Mask)
{
	return _controlfp(NewValue, Mask);
}
*/