#pragma once
#include <WinSock.h>

CRITICAL_SECTION g_csSync;